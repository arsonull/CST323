@extends('layouts.app')
@section('content')
<h1>Portfolio failure :(</h1>
@endsection