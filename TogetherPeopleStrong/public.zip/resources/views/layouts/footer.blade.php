<footer class="text-center footer">
        <div class="container">
            <p class="text-muted mb-0 small">Copyright &nbsp;&#169 TogetherPeopleStrong 2021</p>
        </div><a class="js-scroll-trigger scroll-to-top rounded" href="#page-top"><i class="fa fa-angle-up"></i></a>
</footer>